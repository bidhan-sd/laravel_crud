<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit</div>
				
					<form action="<?php echo e(route('/update')); ?>" method="POST" enctype="multipart/form-data" name="crudForm">
					
						<?php echo e(csrf_field()); ?>

						
						<div class="col-md-6 offset-3">
							<label for="name"> Name </label>
							<input type="text" name="name" id="name" class="form-control" placeholder="Name" value="<?php echo e($data->name); ?>">
							<input type="hidden" name="id" id="id"  value="<?php echo e($data->id); ?>">
						</div>
						
						<div class="col-md-6 offset-3 mt-2">
							<label for="gender"> Gender </label>
							<input type="radio" id="gender" name="gender" value="male" <?php if($data->gender == "male"): ?> checked <?php endif; ?>> Male
							<input type="radio" id="gender" name="gender" value="female" <?php if($data->gender == "female"): ?> checked <?php endif; ?>> Female
						</div>
						
						<div class="col-md-6 offset-3  mt-2">
							<label for="sports"> Favourite Sports </label>
							<?php
								$sports = explode(",",$data->sports);
							?>
							
							<input type="checkbox" id="sports" name="sports[]" value="cricket" <?php if(in_array("cricket",$sports)): ?> checked <?php endif; ?> > Cricket
							<input type="checkbox" id="sports" name="sports[]" value="football" <?php if(in_array("football",$sports)): ?> checked <?php endif; ?>> Football
							<input type="checkbox" id="sports" name="sports[]" value="handball" <?php if(in_array("handball",$sports)): ?> checked <?php endif; ?>> Handball
						</div>
						
						<div class="col-md-6 offset-3  mt-2">
							<label for="country"> Country </label>
							<select name="country" id="country">
								<option>Select Country</option>
								<option value="Bangladesh" <?php if($data->country == "Bangladesh"): ?> selected <?php endif; ?> >Bangladesh</option>
								<option value="India" <?php if($data->country == "India"): ?> selected <?php endif; ?> >India</option>
							</select>
						</div>
						
						<div class="col-md-6 offset-3  mt-2">
							<img src="<?php echo e(asset($data->image)); ?>" width="100"/>
						</div>
						<div class="col-md-6 offset-3  mt-2">
							<input type="file" name="image" id="image"/>
						</div>
						
						<div class="col-md-6 offset-3  mt-2">
							<input type="submit" name="submit" value="Update"/>
						</div>
						
					</form>
					
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>